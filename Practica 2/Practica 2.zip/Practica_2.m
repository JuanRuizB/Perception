clear all,close all, clc;
Nx = 200;
Ny = 200;
Fs = 100;
[x1,y1,z1] = sindiscreta2D(Nx,Ny,Fs,Fs,1,15,0,0);
[x2,y2,z2] = sindiscreta2D(Nx,Ny,Fs,Fs,1,0,15,0);
[x3,y3,z3] = sindiscreta2D(Nx,Ny,Fs,Fs,1,15,15,0);

x = x1+x2+x3;
y = y1+y2+y3;
z = z1+z2+z3;

surf(x,y,z),figure,imagesc(x,y,z),colormap gray;

tf = fft2(z);

surf(abs(tf)),figure,imagesc (abs(tf)), colormap gray;

[coefsX,coefsY] = find(abs(tf) > 0.5); %Posicion en la matriz tf de los 
% coeficientes espectrales.

J=fftshift(tf);
figure, imagesc(abs(J)), colormap gray; %Muestra los valores de la frecuencia
% 0 en el centro.

%--------------------------------------------------------------------------
close all;
A = 1;
Fs = 100;
Fx = [eps 5 10 25 50];
Fy = 0;
Fase = 0;
Nx = 200;
Ny = 200;
for i = 1:5
[x,y,z] = sindiscreta2D(Nx,Ny,Fs,Fs,A,Fx(i),Fy,Fase);
figure,surf(x,y,z),figure,imagesc(x,y,z);

tf = fft2(z);

[coefsX,coefsY] = find(abs(tf) > 0.5); %Posicion en la matriz tf de los 
% coeficientes espectrales.
end
